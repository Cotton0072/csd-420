import java.util.Comparator;

/**
 * Bubble_Sort
 * Demonstrates two generic bubble sort methods:
 * 1. Sorting using Comparable (natural ordering)
 * 2. Sorting using Comparator (custom ordering)
 *
 * Both methods use the bubble sort algorithm.
 */
public class Bubble_Sort {

    /**
     * Bubble sort using Comparable.
     * This method requires the elements to implement Comparable<T>.
     *
     * @param array The array to be sorted
     * @param <T>   Any type that implements Comparable<T>
     */
    public static <T extends Comparable<T>> void bubbleSortComparable(T[] array) {
        boolean swapped;

        for (int i = 0; i < array.length - 1; i++) {
            swapped = false;

            for (int j = 0; j < array.length - 1 - i; j++) {
                if (array[j].compareTo(array[j + 1]) > 0) {
                    T temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break; // Optimization: stop early if already sorted
            }
        }
    }

    /**
     * Bubble sort using a Comparator.
     * This allows custom sorting logic to be passed in.
     *
     * @param array The array to be sorted
     * @param comp  Comparator defining the sorting rules
     * @param <T>   Any type
     */
    public static <T> void bubbleSortComparator(T[] array, Comparator<T> comp) {
        boolean swapped;

        for (int i = 0; i < array.length - 1; i++) {
            swapped = false;

            for (int j = 0; j < array.length - 1 - i; j++) {
                if (comp.compare(array[j], array[j + 1]) > 0) {
                    T temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                    swapped = true;
                }
            }

            if (!swapped) {
                break; // Optimization: stop early if already sorted
            }
        }
    }
}
