import java.util.Arrays;
import java.util.Comparator;

/**
 * TestBubbleSort
 * Runs test cases for both bubble sort methods:
 * - Comparable-based sorting
 * - Comparator-based sorting
 */
public class TestBubbleSort {

    public static void main(String[] args) {

        // -------------------------------
        // Test 1: Comparable bubble sort
        // -------------------------------
        Integer[] nums = {5, 1, 4, 2, 8};

        System.out.println("Original Integer array: " + Arrays.toString(nums));

        Bubble_Sort.bubbleSortComparable(nums);

        System.out.println("Sorted (Comparable): " + Arrays.toString(nums));


        // -----------------------------------------
        // Test 2: Comparator bubble sort (by length)
        // -----------------------------------------
        String[] words = {"apple", "kiwi", "banana", "fig"};

        System.out.println("\nOriginal String array: " + Arrays.toString(words));

        Comparator<String> lengthComparator = (a, b) -> a.length() - b.length();

        Bubble_Sort.bubbleSortComparator(words, lengthComparator);

        System.out.println("Sorted (Comparator - by length): " + Arrays.toString(words));


        // ---------------------------------------------------
        // Test 3: Comparator bubble sort (alphabetical order)
        // ---------------------------------------------------
        String[] words2 = {"zebra", "cat", "monkey", "bear"};

        System.out.println("\nOriginal String array: " + Arrays.toString(words2));

        Bubble_Sort.bubbleSortComparator(words2, String::compareTo);

        System.out.println("Sorted (Comparator - alphabetical): " + Arrays.toString(words2));
    }
}
