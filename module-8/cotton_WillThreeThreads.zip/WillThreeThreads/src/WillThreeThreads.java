public class WillThreeThreads {

    public static void main(String[] args) {

        Thread letters = new Thread(() -> {
            for (int i = 0; i < 5000; i++) {
                char c = (char) ('a' + (int)(Math.random() * 26));
                System.out.print(c);
            }
        });

        Thread digits = new Thread(() -> {
            for (int i = 0; i < 5000; i++) {
                char d = (char) ('0' + (int)(Math.random() * 10));
                System.out.print(d);
            }
        });

        Thread symbols = new Thread(() -> {
            char[] set = {'!', '?', '+', '-', '=', '~'};
            for (int i = 0; i < 5000; i++) {
                char s = set[(int)(Math.random() * set.length)];
                System.out.print(s);
            }
        });

        letters.start();
        digits.start();
        symbols.start();
    }
}
