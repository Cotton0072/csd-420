import javax.json.*;
import java.io.StringReader;

public class StreamingReadExample {
    public static void main(String[] args) {
        String json = "{ \"id\": 10, \"status\": \"active\" }";

        JsonParser parser = Json.createParser(new StringReader(json));
        while (parser.hasNext()) {
            JsonParser.Event event = parser.next();
            System.out.println("Event: " + event);
        }
    }
}
