import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class FanViewerApp extends JFrame {

    private JTextField txtId, txtFirst, txtLast, txtTeam;
    private JButton btnDisplay, btnUpdate;

    private final String URL = "jdbc:mysql://localhost:3306/databasedb";
    private final String USER = "student1";
    private final String PASS = "pass";

    public FanViewerApp() {
        super("Fan Viewer App");

        setLayout(new GridLayout(6, 2, 5, 5));

        add(new JLabel("ID:"));
        txtId = new JTextField();
        add(txtId);

        add(new JLabel("First Name:"));
        txtFirst = new JTextField();
        add(txtFirst);

        add(new JLabel("Last Name:"));
        txtLast = new JTextField();
        add(txtLast);

        add(new JLabel("Favorite Team:"));
        txtTeam = new JTextField();
        add(txtTeam);

        btnDisplay = new JButton("Display");
        btnUpdate = new JButton("Update");

        add(btnDisplay);
        add(btnUpdate);

        btnDisplay.addActionListener(e -> displayRecord());
        btnUpdate.addActionListener(e -> updateRecord());

        setSize(350, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    private void displayRecord() {
        String sql = "SELECT firstname, lastname, favoriteteam FROM fans WHERE id = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, Integer.parseInt(txtId.getText()));
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                txtFirst.setText(rs.getString("firstname"));
                txtLast.setText(rs.getString("lastname"));
                txtTeam.setText(rs.getString("favoriteteam"));
            } else {
                JOptionPane.showMessageDialog(this, "Record not found.");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void updateRecord() {
        String sql = "UPDATE fans SET firstname = ?, lastname = ?, favoriteteam = ? WHERE id = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, txtFirst.getText());
            stmt.setString(2, txtLast.getText());
            stmt.setString(3, txtTeam.getText());
            stmt.setInt(4, Integer.parseInt(txtId.getText()));

            int rows = stmt.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Record updated successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Update failed. ID not found.");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new FanViewerApp();
    }
}
