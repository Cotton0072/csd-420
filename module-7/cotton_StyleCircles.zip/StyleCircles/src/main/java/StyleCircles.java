package main.java;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class StyleCircles extends Application {

    @Override
    public void start(Stage stage) {

        // Circles using class selector
        Circle c1 = new Circle(50);
        c1.getStyleClass().add("whiteFillBlackStroke");

        Circle c2 = new Circle(50);
        c2.getStyleClass().add("whiteFillBlackStroke");

        // Circles using ID selector
        Circle c3 = new Circle(50);
        c3.setId("redCircle");

        Circle c4 = new Circle(50);
        c4.setId("greenCircle");

        HBox root = new HBox(20);
        root.getChildren().addAll(c1, c2, c3, c4);

        Scene scene = new Scene(root, 500, 150);

        // Load external CSS
        scene.getStylesheets().add("main/resources/mystyle.css");

        stage.setTitle("Circle Style Demo");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
