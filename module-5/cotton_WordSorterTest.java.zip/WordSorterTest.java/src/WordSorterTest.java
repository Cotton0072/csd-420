import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.Collections;

public class WordSorterTest {

    public static void main(String[] args) {

        // TreeSet automatically removes duplicates AND sorts ascending
        Set<String> ascendingSet = new TreeSet<>();

        try {
            File file = new File("collection_of_words.txt");
            Scanner input = new Scanner(file);

            // Read all words from the file
            while (input.hasNext()) {
                String word = input.next().toLowerCase().replaceAll("[^a-zA-Z]", "");
                if (!word.isEmpty()) {
                    ascendingSet.add(word);
                }
            }

            input.close();

            // Display ascending order
            System.out.println("Ascending Order:");
            for (String word : ascendingSet) {
                System.out.println(word);
            }

            // Display descending order
            System.out.println("\nDescending Order:");
            ascendingSet.stream()
                    .sorted(Collections.reverseOrder())
                    .forEach(System.out::println);

            // TEST CODE
            System.out.println("\n--- TEST CODE OUTPUT ---");
            System.out.println("Total unique words: " + ascendingSet.size());
            System.out.println("Contains 'example'? " + ascendingSet.contains("example"));

        } catch (FileNotFoundException e) {
            System.out.println("File not found. Make sure collection_of_words.txt is in the project folder.");
        }
    }
}
